package org.bdebeach.bdebeach;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BdebeachApplication {

	public static void main(String[] args) {
		SpringApplication.run(BdebeachApplication.class, args);
	}

}
